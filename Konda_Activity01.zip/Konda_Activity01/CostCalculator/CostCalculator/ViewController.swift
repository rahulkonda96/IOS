//
//  ViewController.swift
//  CostCalculator
//
//  Created by Konda,Rahul on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var product1Name: UITextField!
    
    @IBOutlet weak var product1Price: UITextField!
    
    @IBOutlet weak var product2Name: UITextField!
    
    @IBOutlet weak var product2Price: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var prod1Name: UILabel!
    
    @IBOutlet weak var prod1Price: UILabel!
    
    @IBOutlet weak var prod2Name: UILabel!
    
    @IBOutlet weak var prod2Price: UILabel!
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        
        var num1 = Double(product1Price.text!)
        var num2 = Double(product2Price.text!)
        let taxRate : Double = 8.5
        let discountRate : Double = 25
        var tax = Double(taxRate/100)
        var dis = Double(discountRate/100)
        
        var dis1 = num1! - (num1! * dis)
        var dis2 = num2! - (num2! * dis)
        var tax1 = dis1 + (dis1 * tax)
        var tax2 = dis2 + (dis2 * tax)
        
    
        displayLabel.text = "\(round((tax1 + tax2) * 100) / 100.0)"
        prod1Name.text = "\(product1Name.text!)"
        prod1Price.text = "$\(product1Price.text!)"
        prod2Name.text = "\(product2Name.text!)"
        prod2Price.text = "$\(product2Price.text!)"

        
    }
    
}

