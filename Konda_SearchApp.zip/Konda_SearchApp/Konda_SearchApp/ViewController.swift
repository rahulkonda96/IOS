//
//  ViewController.swift
//  Konda_SearchApp
//
//  Created by student on 3/2/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchButtonAction: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var showPrevImagesBtn: UIButton!
    
    @IBOutlet weak var showNextImagesBtn: UIButton!
    
    var arr = [["player1","player2","player3","player4","player5"],["place1","place2","place3","place4","place5"],["actor1","actor2","actor3","actor4","actor5",],["bg","404"]]
    
    var players = ["player","players","cricketer","cricket","dravid","sachin","abdevilliers","dhoni","kallis","celebrity","batsmen","match"]
    
    var places = ["places","place","barcelona","paris","sydney","rome","mysore","journey","roam","memories","travelling"]
        
    var actors = ["actor","actors","hero","tollywood","maheshbabu","prabhas","raviteja","ramcharan","venkatesh","celebrity","hero","film"]

    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        searchButtonAction.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
        
    }
    
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButtonAction.isEnabled = true
        if(sender.text == ""){
            searchButtonAction.isEnabled = false
            
        }
        else{
            showPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            searchButtonAction.isEnabled = true
            resetButton.isHidden = true
        }
    }
    
    var player = [["Dravid", "Sachin", "AbDevilliers", "Dhoni", "Kallis"],["Rahul Sharad Dravid born 11 January 1973 is a former Indian cricketer and captain of the Indian national team, currently serving as its head coach. Prior to his appointment to the senior mens national team, Dravid was the Head of Cricket at the National Cricket Academy (NCA).","Sachin Ramesh Tendulkar; born 24 April 1973 is an Indian former international cricketer who captained the Indian national team. He is regarded as one of the greatest batsmen in the history of cricket. He is the highest run scorer of all time in international cricket, and the only player to have scored one hundred international centuries.","Abraham Benjamin de Villiers (born 17 February 1984) is a former South African international cricketer. De Villiers was named as the ICC ODI Player of the Year three times during his 15-year international career and was one of the five Wisden cricketers of the decade at the end of 2019. AB de Villiers began his international career as a wicket-keeper-batsman.","Mahendra Singh Dhoni (born 7 July 1981) is a former international cricketer who played as a right-handed wicketkeeper batsman . His power hitting ability and offensive batting style made his reputation as a finisher. He is widely considered as one of the greatest white ball cricket captain ever. He captained the Indian national cricket team in limited-overs formats from 2007 to 2017 and in Test cricket from 2008 to 2014.","Jacques Henry Kallis (born 16 October 1975) is a South African cricket coach and former cricketer. Widely regarded as one of the greatest cricketers of all time and as South Africa's greatest batsman ever, he is a right-handed batsman and right-arm fast-medium swing bowler. As of 2021 he is the only cricketer in the history of the game to score more than 10,000 runs and take over 250 wickets in both ODI and Test match cricket."]]
    
    
    var place = [["Barcelona","Paris","Sydney","Rome","Mysore"],["Barcelona , Spanish: is a city on the coast of northeastern Spain. It is the capital and largest city of the autonomous community of Catalonia, as well as the second most populous municipality of Spain. With a population of 1.6 million within city limits, its urban area extends to numerous neighbouring municipalities within the Province of Barcelona and is home to around 4.8 million people.","Paris is the capital and most populous city of France, with an estimated population of 2,165,423 residents in 2019 in an area of more than 105 square kilometres (41 square miles). Since the 17th century, Paris has been one of the world's major centres of finance, diplomacy, commerce, fashion, gastronomy, science, and arts. It is estimated with population of 12,174,880 in 2017, or about 18 percent of the population of France.","Sydney SID-nee; Dharug: Gadi. Greater Sydney, Dharug: Eora) is the capital city of the state of New South Wales, and the most populous city in Australia and Oceania. Located on Australia's east coast, the metropolis surrounds Port Jackson and extends about 70 km (43.5 mi) on its periphery towards the Blue Mountains to the west, Hawkesbury to the north, the Royal National Park to the south and Macarthur to the south-west.","Rome is the capital city of Italy. It is also the capital of the Lazio region, the centre of the Metropolitan City of Rome, and a special comune named Comune di Roma Capitale. With 2,860,009 residents in 1,285 km2 (496.1 sq mi), Rome is the country's most populated comune and the third most populous city in the European Union by population within city limits.","Mysore, officially Mysuru, is a city in the southern part of the state of Karnataka, India. Mysore city is geographically located between 12° 18′ 26″ north latitude and 76° 38′ 59″ east longitude. It is located at an altitude of 770 m (2,530 ft) above mean sea level. It served as the capital city of the Kingdom of Mysore for nearly six centuries from 1399 until 1956."]]
    
    var actor = [["Mahesh Babu","Prabhas","Ravi Teja","Ramcharan","Venkatesh"],["Ghattamaneni Mahesh Babu (born 9 August 1975) is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema. He has appeared in more than 25 films, and won several accolades including, eight Nandi Awards, five Filmfare South Awards, four South Indian International Movie Awards, three CineMAA Awards, and one IIFA Utsavam Award.","Uppalapati Venkata Suryanarayana Prabhas Raju (born 23 October 1979), known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema, Prabhas has featured in Forbes India's Celebrity 100 list three times since 2015 based on his income and popularity.","Ravi Shankar Raju Bhupatiraju (born 26 January 1968), better known by the stage name Ravi Teja, is an Indian actor who predominantly works in Telugu cinema. Known for his roles in action comedy films, Teja has appeared in over 70 films and is one of the highest paid actors in Telugu film industry. He won the Nandi Special Jury Award in 1999 and 2002 for his performance in the films Nee Kosam (1999) and Khadgam (2002).","Konidela Ram Charan Teja (born 27 March 1985) is an Indian actor, producer and entrepreneur who works predominantly in Telugu cinema. One of the highest-paid actors in India, he is the recipient of several awards, including three Filmfare Awards and two Nandi Awards. Since 2013, he has been featured in Forbes India's Celebrity 100 list based on his income and popularity.","Daggubati Venkatesh (born 13 December 1960), known mononymously as Venkatesh, is an Indian film actor known for his works predominantly in Telugu cinema. Venkatesh debuted with the 1986 film Kaliyuga Pandavulu for which he won his first Nandi Award. In a career spanning over 30 years, he starred in many successful films."]]
    
    
    @IBAction func searchButtonActionAction(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        showPrevImagesBtn.isHidden = false
        showNextImagesBtn.isHidden = false
        showPrevImagesBtn.isEnabled = false
        showNextImagesBtn.isEnabled = false
        resetButton.isHidden = false
        if(players.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            showPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[0][imag1])
            topic = 1
            topicInfoText.text = player[1][text1]
        }
        else if(places.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            showPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[1][imag2])
            topic = 2
            topicInfoText.text = place[1][text2]
        }
        else if(actors.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            showPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[2][imag3])
            topic = 3
            topicInfoText.text = actor[1][text3]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])
            topicInfoText.text = nil
            showPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            resetButton.isEnabled = true
        }
        
        
    }
    
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
        
    }
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
        }
    }
    
    
    @IBAction func resetButton(_ sender: Any) {
        showPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        topicInfoText.text = nil
        searchTextField.text = nil
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        imag1 = 0
        imag2 = 0
        imag3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        topic = 0
        
        
    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == arr[0].count-1 {
                showNextImagesBtn.isEnabled = false
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                topicInfoText.text = player[1][text1]
            }
            else if(imag1 == 0){
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                topicInfoText.text = player[1][text1]
            }
            else{
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                topicInfoText.text = player[1][text1]
            }
        }
        if(topic == 2){
            if imag2 == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                topicInfoText.text = place[1][text2]
            }
            else if(imag2 == 0){
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                topicInfoText.text = place[1][text2]
            }
            else{
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                topicInfoText.text = place[1][text2]
                
            }
        }
        if(topic == 3){
            if imag3 == arr[2].count-1 {
                showNextImagesBtn.isEnabled = false
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                topicInfoText.text = actor[1][text3]
            }
            else if(imag3 == 0){
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                topicInfoText.text = actor[1][text3]
            }
            else{
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                topicInfoText.text = actor[1][text3]
                
            }
        }
    }
    
    
}



