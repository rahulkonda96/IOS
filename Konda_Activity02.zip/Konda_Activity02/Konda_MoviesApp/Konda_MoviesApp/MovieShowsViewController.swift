//
//  MovieShowsViewController.swift
//  Konda_MoviesApp
//
//  Created by Konda,Rahul on 4/7/22.
//

import UIKit

class MovieShowsViewController: UIViewController {

    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var previousButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var movieName: UILabel!
    
    @IBOutlet weak var ticketCost: UILabel!
    
    @IBOutlet weak var nameOfPerson: UITextField!
    
    @IBOutlet weak var movieCost: UITextField!
    
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        var num1 = Int(ticketCost.text!)
        var num2 = Int(movieCost.text!)
    }
    
    let courses = [["Avatar", "AVATAR", "10"],
    ["Joker", "JOKER", "20"],
    ["NoTimeToDie", "NOTIMETODIE", "30"],
    ["Shangchi", "SHANGCHI", "40"]
                   ]
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        updateUI(imageNumber)
        previousButton.isEnabled = false
    }
    
    
    @IBAction func previousButtonClicked(_ sender: UIButton) {
        nextButton.isEnabled = true
        imageNumber -= 1
        updateUI(imageNumber)
        if(imageNumber == 0){
            previousButton.isEnabled = false
        }
    }
    
    @IBAction func nextButtonClicked(_ sender: UIButton) {
        imageNumber += 1
        updateUI(imageNumber)
        previousButton.isEnabled = true
        if(imageNumber == courses.count-1){
            nextButton.isEnabled = false
        }
    }
    
    func updateUI(_ imageNum: Int){
        imageDisplay.image = UIImage(named: courses[imageNum][0])
        movieName.text = courses[imageNum][1]
        ticketCost.text = courses[imageNum][2]
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "detailSegue"{
            let destination = segue.destination as!
            BookingDetailsViewController
            
            destination.courses = courses[(buttonClicked(<#T##sender: UIButton##UIButton#>),]
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
