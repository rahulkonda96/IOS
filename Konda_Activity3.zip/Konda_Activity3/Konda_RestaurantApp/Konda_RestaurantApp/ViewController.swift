//
//  ViewController.swift
//  Konda_RestaurantApp
//
//  Created by Konda,Rahul on 4/26/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var restaurant = Restarant()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        restaurant.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = restaurantItemsTableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
                cell.textLabel!.text = restaurant.details[indexPath.row].name
                return cell
    }
    

    @IBOutlet weak var restaurantItemsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        restaurantItemsTableView.delegate = self
        restaurantItemsTableView.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "RestaurantSegue"{
            let destination = segue.destination as! RestaurantDetailsViewController
           // destination.restaurant = restaurant.items_Array[(RestaurantDetailsViewController .indexPathForSelectedRow?.row)!]
    }
    }
    
}

