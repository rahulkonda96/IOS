//
//  RestaurantDetailsViewController.swift
//  Konda_RestaurantApp
//
//  Created by Konda,Rahul on 4/26/22.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {

    var restaurant_item : RestDetails?
    
    @IBOutlet weak var restaurantImageViewOutlet: UIImageView!
    
    @IBOutlet weak var itemInfoOutlet1: UILabel!
    
    @IBOutlet weak var itemInfoOutlet2: UILabel!
    
    @IBOutlet weak var itemInfoOutlet3: UILabel!
    
    @IBOutlet weak var itemInfoOutlet4: UILabel!
    
    @IBOutlet weak var itemInfoOutlet5: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = restaurant_item?.image
        itemInfoOutlet1.text = " "
        itemInfoOutlet2.text = " "
        itemInfoOutlet3.text = " "
        itemInfoOutlet4.text = " "
        itemInfoOutlet5.text = " "
        let img = restaurant_item?.image
        restaurantImageViewOutlet.image = UIImage(named: img!)
        let originalImageFrame = restaurantImageViewOutlet.frame
        let widthShrink: CGFloat = 30
        let heightShrink: CGFloat = 30
        let newFrame = CGRect(
        x: restaurantImageViewOutlet.frame.origin.x + widthShrink,
        y: restaurantImageViewOutlet.frame.origin.y + heightShrink,
        width: restaurantImageViewOutlet.frame.width - widthShrink,
        height: restaurantImageViewOutlet.frame.height - heightShrink)
        restaurantImageViewOutlet.frame = newFrame
        UIView.animate(withDuration: 1.0, delay: 0.7, usingSpringWithDamping: 0.3, initialSpringVelocity: 30.0,  animations: {
                        self.restaurantImageViewOutlet.frame = originalImageFrame
                    })
    }
    
    @IBAction func showItemInfoAction(_ sender: UIButton) {
        itemInfoOutlet1.text = restaurant_item?.item1
        itemInfoOutlet2.text = restaurant_item?.item2
        itemInfoOutlet3.text = restaurant_item?.item3
        itemInfoOutlet4.text = restaurant_item?.item4
        itemInfoOutlet4.text = restaurant_item?.item5
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
