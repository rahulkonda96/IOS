//
//  ViewController.swift
//  CoordinateSystem Demo
//
//  Created by Konda,Rahul on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOutlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX = imageViewOutlet.frame.minX
        let minY = imageViewOutlet.frame.minY
        print("\(minX), \(minY)")
        
        let maxX = imageViewOutlet.frame.maxX
        let maxY = imageViewOutlet.frame.maxY
        print("\(maxX), \(maxY)")
        
        let midX = imageViewOutlet.frame.midX
        let midY = imageViewOutlet.frame.midY
        print("\(midX), \(midY)")
        
        //move the image to upper left corner
        //imageViewOutlet.frame.origin.x = 0
        //imageViewOutlet.frame.origin.y = 0
        
        //move the image to upper right corner
        //imageViewOutlet.frame.origin.x = 314
        //imageViewOutlet.frame.origin.y = 0
        
        //move the image to lower left corner
        //imageViewOutlet.frame.origin.x = 0
        //imageViewOutlet.frame.origin.y = 796
        
        //move the image to lower right corner
        //imageViewOutlet.frame.origin.x = 314
        //imageViewOutlet.frame.origin.y = 796
        
        //move the image to center of the screen //207 //448
        imageViewOutlet.frame.origin.x = midX - 50
        imageViewOutlet.frame.origin.y = midY + 100
    }


}

